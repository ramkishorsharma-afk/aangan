# 🏡 Aangan — आँगन

> *Your digital courtyard. The hyperlocal community platform for Indian neighbourhoods.*

Aangan connects people within the same mohalla/colony — for activities, services, local businesses, and private conversations. Think of it as the digital version of your building's aangan where neighbours actually talk to each other.

---

## 🌟 Features

| Feature | Description |
|---|---|
| **Community Feed** | Post updates, share thoughts, raise local issues |
| **Activities & Events** | "Playing chess at 6 PM, come join!" — with RSVP |
| **Local Businesses** | Neighbourhood-only business listings & notifications |
| **Services** | Find a cook, plumber, electrician, babysitter nearby |
| **Private Chat** | Message neighbours directly and privately |

---

## 📁 Project Structure

```
aangan/
├── index.html        ← Landing page (public-facing)
├── app.html          ← Main app interface
├── css/
│   └── style.css     ← Global styles
├── js/
│   └── app.js        ← App logic (feed, chat, events)
├── README.md
└── .gitignore
```

---

## 🚀 Getting Started

### Run locally
Just open `index.html` in your browser — no server needed for the prototype.

### Deploy to GitHub Pages
1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Set source to `main` branch, `/ (root)`
4. Your site will be live at `https://yourusername.github.io/aangan`

---

## 🗺️ Roadmap

- [x] Landing page
- [x] Community feed (posts, activities, events)
- [x] Local business listings
- [x] Service directory (cook, plumber, etc.)
- [x] Private chat UI
- [ ] User registration & login (PHP/WordPress backend)
- [ ] Locality-based signup (choose your colony/sector)
- [ ] Real-time chat (WebSockets / Pusher)
- [ ] Push notifications
- [ ] Mobile app (React Native)
- [ ] Moderation tools for community admin

---

## 💡 Tech Stack (Planned)

- **Frontend:** HTML, CSS, Vanilla JS → React (later)
- **Backend:** WordPress + BuddyPress or custom PHP
- **Database:** MySQL
- **Hosting:** Shared hosting / VPS

---

## 👤 Author

Built by Ram Kishore Sharma  
Rohtak, Haryana, India

---

## 📄 License

MIT License — free to use and modify.
