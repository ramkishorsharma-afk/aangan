/**
 * Aangan — आँगन
 * Main App JavaScript
 * Hyperlocal Community Platform
 */

/* =============================================
   STATE
   ============================================= */
const state = {
  currentTab: 'feed',
  currentChat: 'mohan',
  posts: [
    {
      id: 1, author: 'Vikram Kumar', initials: 'VK', block: '22-B',
      time: '20 min ago', tag: 'activity', tagLabel: 'Activity',
      body: 'Playing chess at the park this evening! Anyone who wants to join, come at 6 PM. Beginners welcome, we have extra sets. 🎲',
      event: 'Today, 6:00 PM · Near Gate 3 Park',
      likes: 5, comments: 3, joined: 3
    },
    {
      id: 2, author: 'Priya Rani', initials: 'PR', block: '22-A',
      time: '1 hr ago', tag: 'general', tagLabel: 'General',
      body: 'The streetlight near B-block has been broken for 4 days. I have filed a complaint. If anyone else faces this, please support on MC portal too. 💡',
      event: null,
      likes: 12, comments: 5, joined: 0
    },
    {
      id: 3, author: 'Mohan Gupta', initials: 'MG', block: '22-D',
      time: '3 hr ago', tag: 'service', tagLabel: 'Need help',
      body: 'Does anyone know a good plumber in the area? My kitchen pipe is leaking badly. Need someone today if possible. 🔧',
      event: null,
      likes: 0, comments: 8, joined: 0
    }
  ],
  chats: {
    mohan: {
      name: 'Mohan Gupta', initials: 'MG', avClass: 'av-amber', block: '22-D', status: 'online',
      messages: [
        { from: 'them', text: 'Namaste! Did you see my post about the plumber? Kitchen pipe is leaking badly 😅', time: '2:30 PM' },
        { from: 'them', text: 'If you know anyone reliable, please share number', time: '2:31 PM' },
        { from: 'me',   text: 'Yes saw it! I know Ramesh bhai in 22-A, very reliable. Let me find his number', time: '2:45 PM' }
      ]
    },
    meera: {
      name: "Meera's Bakery", initials: 'MB', avClass: 'av-coral', block: '22-C', status: 'away',
      messages: [
        { from: 'them', text: 'Hello! Your order of 1 kg cake is confirmed for tomorrow morning 🎂', time: '10:00 AM' },
        { from: 'me',   text: 'Great! Please deliver by 9 AM', time: '10:05 AM' },
        { from: 'them', text: 'Of course, will be there by 8:45 AM', time: '10:07 AM' }
      ]
    },
    sunita: {
      name: 'Sunita Lal', initials: 'SL', avClass: 'av-green', block: '22-A', status: 'online',
      messages: [
        { from: 'them', text: 'Are you coming to yoga tomorrow morning?', time: 'Yesterday' },
        { from: 'me',   text: 'Yes! 6:30 AM right?', time: 'Yesterday' },
        { from: 'them', text: 'Yes! See you there 🧘‍♀️', time: 'Yesterday' }
      ]
    }
  }
};

/* =============================================
   TAB NAVIGATION
   ============================================= */
function showTab(tabId) {
  // Update nav
  document.querySelectorAll('.nav-item').forEach(el => {
    el.classList.toggle('active', el.dataset.tab === tabId);
  });
  // Update sections
  document.querySelectorAll('.app-section').forEach(el => {
    el.classList.toggle('active', el.id === 'sec-' + tabId);
  });
  // Update topbar title
  const titles = {
    feed:     'Community Feed',
    events:   'Events',
    business: 'Local Businesses',
    services: 'Services & Help',
    chat:     'Private Chats'
  };
  const titleEl = document.getElementById('tab-title');
  if (titleEl) titleEl.textContent = titles[tabId] || '';
  state.currentTab = tabId;
}

/* =============================================
   POSTS / FEED
   ============================================= */
function renderFeed() {
  const container = document.getElementById('posts-container');
  if (!container) return;
  container.innerHTML = state.posts.map(post => buildPostHTML(post)).join('');
}

function buildPostHTML(post) {
  const avClass = { VK: 'av-purple', PR: 'av-green', MG: 'av-amber', SL: 'av-coral', RWA: 'av-blue' };
  const tagClass = { activity: 'tag-green', general: 'tag-gray', service: 'tag-purple', event: 'tag-amber' };

  const eventLine = post.event
    ? `<div class="post-event-time"><span class="icon">🕐</span>${post.event}</div>`
    : '';

  const joinBtn = post.joined > 0
    ? `<button class="action-btn join-btn" onclick="joinPost(${post.id})">👋 Join (${post.joined} going)</button>`
    : '';

  return `
    <div class="post-card card" id="post-${post.id}">
      <div class="post-header">
        <div class="avatar ${avClass[post.initials] || 'av-green'}">${post.initials}</div>
        <div class="post-meta">
          <strong>${post.author}</strong>
          <span>Block ${post.block} · ${post.time}</span>
        </div>
        <span class="tag ${tagClass[post.tag] || 'tag-gray'}">${post.tagLabel}</span>
      </div>
      ${eventLine}
      <div class="post-body">${post.body}</div>
      <div class="post-actions">
        ${joinBtn}
        <button class="action-btn" onclick="likePost(${post.id})">👍 ${post.likes}</button>
        <button class="action-btn">💬 ${post.comments} comments</button>
        <button class="action-btn" onclick="openPrivateChat()">🔒 Message privately</button>
      </div>
    </div>`;
}

function likePost(id) {
  const post = state.posts.find(p => p.id === id);
  if (post) { post.likes++; renderFeed(); }
}

function joinPost(id) {
  const post = state.posts.find(p => p.id === id);
  if (post) { post.joined++; renderFeed(); }
}

/* =============================================
   NEW POST MODAL
   ============================================= */
function openPostModal() {
  document.getElementById('post-modal').classList.add('open');
  document.getElementById('post-body-input').focus();
}

function closePostModal() {
  document.getElementById('post-modal').classList.remove('open');
}

function submitPost() {
  const body = document.getElementById('post-body-input').value.trim();
  const type = document.getElementById('post-type-select').value;
  const eventTime = document.getElementById('post-event-time').value.trim();
  if (!body) { alert('Please write something to post.'); return; }

  const tagMap = {
    general:  { tag: 'general',  label: 'General' },
    activity: { tag: 'activity', label: 'Activity' },
    service:  { tag: 'service',  label: 'Need help' },
    event:    { tag: 'event',    label: 'Event' },
    alert:    { tag: 'general',  label: 'Alert' }
  };
  const t = tagMap[type] || tagMap.general;

  const newPost = {
    id: Date.now(),
    author: 'Ram Sharma', initials: 'RS', block: '22-C',
    time: 'Just now', tag: t.tag, tagLabel: t.label,
    body: body,
    event: eventTime || null,
    likes: 0, comments: 0, joined: type === 'activity' ? 0 : 0
  };

  state.posts.unshift(newPost);
  renderFeed();
  closePostModal();
  document.getElementById('post-body-input').value = '';
  document.getElementById('post-event-time').value = '';
}

/* =============================================
   BUSINESS MODAL
   ============================================= */
function openBizModal() {
  document.getElementById('biz-modal').classList.add('open');
}

function closeBizModal() {
  document.getElementById('biz-modal').classList.remove('open');
}

function submitBiz() {
  const name = document.getElementById('biz-name').value.trim();
  if (!name) { alert('Please enter business name.'); return; }
  closeBizModal();
  showToast('Business submitted for review! We will notify you within 24 hrs.');
}

/* =============================================
   PRIVATE CHAT
   ============================================= */
function renderChatList() {
  const container = document.getElementById('chat-list');
  if (!container) return;
  const unreadMap = { mohan: 2, meera: 0, sunita: 1 };
  container.innerHTML = Object.entries(state.chats).map(([key, chat]) => {
    const lastMsg = chat.messages[chat.messages.length - 1];
    const unread = unreadMap[key] || 0;
    const isActive = state.currentChat === key;
    return `
      <div class="chat-item ${isActive ? 'active-chat' : ''}" onclick="openChat('${key}')">
        <div class="avatar ${chat.avClass}" style="width:34px;height:34px;font-size:12px">${chat.initials}</div>
        <div class="chat-meta">
          <strong>${chat.name}</strong>
          <span>${lastMsg.text.substring(0, 28)}${lastMsg.text.length > 28 ? '…' : ''}</span>
        </div>
        ${unread > 0 ? `<div class="unread-badge">${unread}</div>` : ''}
      </div>`;
  }).join('');
}

function openChat(key) {
  state.currentChat = key;
  const chat = state.chats[key];
  if (!chat) return;

  // Update list active state
  document.querySelectorAll('.chat-item').forEach(el => el.classList.remove('active-chat'));
  const items = document.querySelectorAll('.chat-item');
  const keys = Object.keys(state.chats);
  const idx = keys.indexOf(key);
  if (items[idx]) items[idx].classList.add('active-chat');

  // Update header
  document.getElementById('chat-person-name').textContent = chat.name;
  document.getElementById('chat-person-sub').textContent = `Block ${chat.block} · ${chat.status}`;
  document.getElementById('chat-person-av').className = `avatar ${chat.avClass}`;
  document.getElementById('chat-person-av').textContent = chat.initials;

  // Render messages
  renderMessages(key);
}

function renderMessages(key) {
  const chat = state.chats[key];
  const area = document.getElementById('msg-area');
  if (!area || !chat) return;
  area.innerHTML = chat.messages.map(msg => `
    <div class="msg ${msg.from === 'me' ? 'me' : 'other'}">
      <div class="msg-bubble">${msg.text}</div>
      <div class="msg-time">${msg.time}</div>
    </div>`).join('');
  area.scrollTop = area.scrollHeight;
}

function sendMessage() {
  const inp = document.getElementById('chat-input');
  if (!inp || !inp.value.trim()) return;
  const chat = state.chats[state.currentChat];
  if (!chat) return;

  const now = new Date();
  const time = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0');
  chat.messages.push({ from: 'me', text: inp.value.trim(), time });
  inp.value = '';
  renderMessages(state.currentChat);
  renderChatList();
}

function openPrivateChat() {
  showTab('chat');
  document.querySelectorAll('.nav-item').forEach(el => {
    if (el.dataset.tab === 'chat') el.classList.add('active');
    else el.classList.remove('active');
  });
}

/* =============================================
   TOAST NOTIFICATION
   ============================================= */
function showToast(msg) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.style.cssText = `
      position:fixed; bottom:24px; left:50%; transform:translateX(-50%);
      background:#1D9E75; color:#fff; padding:10px 20px;
      border-radius:10px; font-size:13px; z-index:9999;
      box-shadow:0 4px 16px rgba(0,0,0,0.15); transition:opacity 0.3s;
    `;
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  setTimeout(() => { toast.style.opacity = '0'; }, 3000);
}

/* =============================================
   MODAL CLOSE ON BG CLICK
   ============================================= */
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-bg')) {
    e.target.classList.remove('open');
  }
});

/* =============================================
   KEYBOARD SHORTCUTS
   ============================================= */
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-bg.open').forEach(m => m.classList.remove('open'));
  }
  if (e.key === 'Enter' && document.activeElement.id === 'chat-input') {
    sendMessage();
  }
});

/* =============================================
   INIT
   ============================================= */
document.addEventListener('DOMContentLoaded', function() {
  renderFeed();
  renderChatList();
  renderMessages('mohan');

  // Nav click handlers
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', function() {
      showTab(this.dataset.tab);
    });
  });
});
